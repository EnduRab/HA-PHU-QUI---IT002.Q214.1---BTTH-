#include <iostream>
#include <vector>

using namespace std;
// tinh tong hieu tich 2 ma tran;

struct MaTran {
    int rows,cols;
    vector<vector<int>> Matrix;

    MaTran(int r = 0, int c = 0) : rows(r), cols(c) , Matrix(r, vector<int>(c)) {} 

    void Nhap() {
        cout << "Nhap lan luot hang va cot cua ma tran: ";
        cin >> rows >> cols;
        *this = MaTran(rows,cols);
        cout << "Nhap lan luot cac phan tu cua ma tran: " << "\n";
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < cols; j++) {
                cin >> Matrix[i][j];
            }
        }
    }

    void Xuat() {
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < cols; j++) {
                cout << Matrix[i][j] << " ";
            }
            cout << "\n";
        }
    }

    MaTran operator+(const MaTran &other) {
        if(!IsSameSize(other)) {
            cout << "Hai ma tran khong cung kich thuoc, khong the thuc hien phep cong" << "\n";
            return MaTran();
        }
        MaTran result(rows,cols);
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < cols; j++) {
                result.Matrix[i][j] = Matrix[i][j] + other.Matrix[i][j];
            }
        }
        return result;
    }

    MaTran operator-(const MaTran &other) {
        if(!IsSameSize(other)) {
            cout << "Hai ma tran khong cung kich thuoc, khong the thuc hien phep tru" << "\n";
            return MaTran();
        }
        MaTran result(rows,cols);
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < cols; j++) {
                result.Matrix[i][j] = Matrix[i][j] - other.Matrix[i][j];
            }
        }
        return result;
    }   

    MaTran operator*(const MaTran &other) {
        if(!Possible_for_multiply(other)) {
            cout << "So cot cua ma tran 1 phai bang so hang cua ma tran 2, khong the thuc hien phep nhan" << "\n";
            return MaTran();
        }
        MaTran result(rows,other.cols);
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < other.cols; j++) {
                result.Matrix[i][j] = 0;
                for(int k = 0; k < cols; k++) {
                    result.Matrix[i][j] += Matrix[i][k] * other.Matrix[k][j];
                }
            }
        }
        return result;
    }   

    bool IsSameSize(const MaTran &other) {
        return (rows == other.rows && cols == other.cols);
    }

    bool Possible_for_multiply(const MaTran &other) {
        return (cols == other.rows);
    }
};

int main() {
    MaTran a,b,tong,hieu,tich;
    a.Nhap();
    b.Nhap();
    tong = a + b;
    hieu = a - b;
    tich = a * b;
    if(a.IsSameSize(b)) {
        cout << "Tong 2 ma tran la: " << "\n";
        tong.Xuat();
    }
    if(a.IsSameSize(b)) {  
        cout << "Hieu 2 ma tran la: " << "\n";
        hieu.Xuat();
    }
    if(a.Possible_for_multiply(b)) {
        cout << "Tich 2 ma tran la: " << "\n";
        tich.Xuat();
    }
}
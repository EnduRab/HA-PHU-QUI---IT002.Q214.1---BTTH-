#include <iostream>
#include <cmath>
#include <numeric> 
#include <vector>
#include <climits>

using namespace std;

struct PhanSo {

    int tu;
    int mau;

    int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }
    void rutGon() {
        if (mau == 0) return;
        int ucln = gcd(abs(tu), abs(mau));
        tu /= ucln;
        mau /= ucln;
        if (mau < 0) {
            tu = -tu;
            mau = -mau;
        }
    }

    PhanSo(int t = 0, int m = 1) : tu(t), mau(m) {
        if (m == 0) mau = 1; 
        rutGon();
    }

    void nhap() {
        cout << "Nhap lan luot Tu va Mau (Cach nhau boi phim cach): ";
        cin >> tu >> mau;
        if (mau == 0) mau = 1;
        rutGon();
    }

    void xuat() const {
        if (mau == 1) cout << tu << endl;
        else cout << tu << "/" << mau << endl;
    }

    double FractionToDouble() {
        return (double)tu/mau;
    }

    PhanSo operator+(const PhanSo& other) const {
        return PhanSo(tu * other.mau + other.tu * mau, mau * other.mau);
    }

    PhanSo operator-(const PhanSo& other) const {
        return PhanSo(tu * other.mau - other.tu * mau, mau * other.mau);
    }

    PhanSo operator*(const PhanSo& other) const {
        return PhanSo(tu * other.tu, mau * other.mau);
    }

    PhanSo operator/(const PhanSo& other) const {
        return PhanSo(tu * other.mau, mau * other.tu);
    }
};

void NhapDayPS(vector<PhanSo> &ds) {
    int n;
    cout << "Nhap so luong phan so muon nhap: ";
    cin >> n;
    for(int i = 0; i < n; i++) {
        PhanSo ps;
        cout << "Phan so thu " << i + 1<< ": " << "\n";
        ps.nhap();
        ds.push_back(ps);
    }
}

PhanSo TongDayPS(const vector<PhanSo> &ds) {
    PhanSo result;
    for(int i = 0; i < ds.size();i++) {
        result = result + ds[i];
    }
    return result;
}


int FindMaxPS(vector<PhanSo> ds) {
    double MaxVal = INT_MIN;
    int index = 0;
    for(int i = 0; i < ds.size();i++) {
        double temp = ds[i].FractionToDouble();
        if(temp > MaxVal) {
            index = i;
            MaxVal = temp;
        }
    }
    return index;
}

int main() {
    vector<PhanSo> ds;
    NhapDayPS(ds);
    PhanSo tong = TongDayPS(ds);
    cout << "Tong cac day phan so la: ";
    tong.xuat();
    if(tong.mau != 1)
        cout << "Duoi dang thap phan la: " << tong.FractionToDouble() << "\n";
    cout << "Phan so lon nhat la: ";
    ds[FindMaxPS(ds)].xuat();
}
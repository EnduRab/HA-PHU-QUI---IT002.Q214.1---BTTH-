#include <iostream>
#include <cmath>
#include <numeric> 

using namespace std;

struct PhanSo {

    int tu;
    int mau;

    int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    void rutGon() {
        if (mau == 0) return;
        int ucln = gcd(abs(tu), abs(mau));
        tu /= ucln;
        mau /= ucln;
        if (mau < 0) {
            tu = -tu;
            mau = -mau;
        }
    }

    PhanSo(int t = 0, int m = 1) : tu(t), mau(m) {
        if (m == 0) mau = 1; 
        rutGon();
    }

    void nhap() {
        cout << "Nhap tu va mau: ";
        cin >> tu >> mau;
        if (mau == 0) mau = 1;
        rutGon();
    }

    void xuat() const {
        if (mau == 1) cout << tu << endl;
        else cout << tu << "/" << mau << endl;
    }

    PhanSo operator+(const PhanSo& other) const {
        return PhanSo(tu * other.mau + other.tu * mau, mau * other.mau);
    }

    PhanSo operator-(const PhanSo& other) const {
        return PhanSo(tu * other.mau - other.tu * mau, mau * other.mau);
    }

    PhanSo operator*(const PhanSo& other) const {
        return PhanSo(tu * other.tu, mau * other.mau);
    }

    PhanSo operator/(const PhanSo& other) const {
        return PhanSo(tu * other.mau, mau * other.tu);
    }
};

int main() {
    PhanSo ps1, ps2;
    
    cout << "Phan so 1:\n"; ps1.nhap();
    cout << "Phan so 2:\n"; ps2.nhap();

    PhanSo tong = ps1 + ps2;
    PhanSo hieu = ps1 - ps2;
    PhanSo tich = ps1 * ps2;
    PhanSo thuong = ps1 / ps2;

    cout << "Tong: "; tong.xuat();
    cout << "Hieu: "; hieu.xuat();
    cout << "Tich: "; tich.xuat();
    cout << "Thuong: "; thuong.xuat();

    return 0;
}
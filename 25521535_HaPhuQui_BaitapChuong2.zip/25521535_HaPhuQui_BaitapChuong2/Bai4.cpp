#include <iostream>
#include <cctype>
using namespace std;

struct HocSinh {
    string MaHocSinh;
    string HoVaTen;
    char Gender;
    float diemToan;
    float diemLy;
    float diemHoa;
    float GPA;

    HocSinh(string ID = " ", string Name = " ", char GioiTinh = ' ', float Toan = 0, float Ly = 0, float Hoa = 0, float DTB = 0) 
    : MaHocSinh(ID),HoVaTen(Name),Gender(GioiTinh),diemToan(Toan),diemHoa(Hoa),diemLy(Ly),GPA(DTB) {
        
    }

    float CalcGPA() {
        return (diemToan + diemLy + diemHoa)/3.0;
    }

    float NhapDiem(string monHoc) {
        float diem;
        do {
            cout << "Nhap diem " << monHoc << ": ";
            cin >> diem;
            if(diem < 0 || diem > 10) {
                cout << "Diem khong hop le." << "\n";
            }
        }  while (diem < 0 || diem > 10);
        return diem;
    }

    void NhapHocSinh() {
        cout << "Nhap ma hoc sinh: " << "\n";
        getline(cin,MaHocSinh);
        cout << "Nhap ho va ten: " << "\n";
        getline(cin,HoVaTen);
        do {
            cout << "Nhap gioi tinh (Nam nhap 'M', Nu nhap 'F'): ";
            cin >> Gender;
        } while (!ValidGender());
        diemToan = NhapDiem("Toan");
        diemLy = NhapDiem("Ly");
        diemHoa = NhapDiem("Hoa");
        GPA = CalcGPA();

        cin.ignore(1000, '\n');
    }

    void printHocSinh() {
        cout << "Ma hoc sinh: " << MaHocSinh << "\n";
        cout << "Ho va Ten: " << HoVaTen << "\n";
        cout << "Gioi tinh: ";
        cout << "Gioi tinh: " << (Gender == 'm' ? "Nam" : "Nu") << "\n";
        cout << "Diem Toan: " << diemToan << "\n";
        cout << "Diem Ly: " << diemLy << "\n";
        cout << "Diem Hoa: " << diemHoa << "\n";
        cout << "Diem Trung Binh: " << GPA << "\n";
    }

    bool ValidGender() {
        Gender = tolower(Gender);
        return (Gender == 'm' || Gender == 'f');
    }
};

int main() {
    HocSinh HS;
    HS.NhapHocSinh();
    HS.printHocSinh();
}